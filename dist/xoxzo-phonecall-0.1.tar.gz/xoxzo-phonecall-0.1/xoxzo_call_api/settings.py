api_call = "https://api.xoxzo.com/voice/simple/playback/"
