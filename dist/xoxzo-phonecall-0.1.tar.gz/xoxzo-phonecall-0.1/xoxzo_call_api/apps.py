from django.apps import AppConfig


class XoxzoCallApiConfig(AppConfig):
    name = 'xoxzo_call_api'
